package LocalDateDemo1;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

class dateDemo{
	
	void dateDemo1() {
		LocalDate D1 = LocalDate.of(2022, 1, 12);		
		System.out.println("Good day : " + D1);
		System.out.println("After 10 days: " + D1.plusDays(10));
		LocalDateTime D2 = LocalDateTime.of(2017, 1, 14, 10, 34);  
		System.out.println("Format : " + D2);
	}
	void dateDemo2() {
		LocalDate D3 = LocalDate.now();
		System.out.println("today Date : " +  D3);		
		
		LocalDate D4 = LocalDate.parse("2021-12-12", DateTimeFormatter.ISO_DATE);
		System.out.println("Formatter : " + D4);
	}
}
public class LocalDateDemo1 {
	public static void main(String[] args) {		
		
		dateDemo demo = new dateDemo();
		demo.dateDemo1();
		demo.dateDemo2();
	}
	
	
}
